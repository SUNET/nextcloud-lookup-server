<?php

namespace LookupServer\Exceptions;

use Exception;

/**
 * Class SignedRequestException
 *
 * @package LookupServer\Exceptions
 */
class SignedRequestException extends Exception {
}
